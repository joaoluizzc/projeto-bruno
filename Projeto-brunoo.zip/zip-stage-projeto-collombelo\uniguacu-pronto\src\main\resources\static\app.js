const endpoints = {
    areas: "/api/areas",
    professores: "/api/professores",
    cursos: "/api/cursos",
    disciplinas: "/api/disciplinas"
};

const state = {
    view: "areas",
    editingId: null,
    search: "",
    data: {
        areas: [],
        professores: [],
        cursos: [],
        disciplinas: []
    }
};

const labels = {
    areas: {
        title: "Areas do conhecimento",
        formTitle: "Cadastrar area",
        editTitle: "Editar area",
        item: "area"
    },
    professores: {
        title: "Professores",
        formTitle: "Cadastrar professor",
        editTitle: "Editar professor",
        item: "professor"
    },
    cursos: {
        title: "Cursos",
        formTitle: "Cadastrar curso",
        editTitle: "Editar curso",
        item: "curso"
    },
    disciplinas: {
        title: "Disciplinas",
        formTitle: "Cadastrar disciplina",
        editTitle: "Editar disciplina",
        item: "disciplina"
    }
};

const elements = {
    navButtons: document.querySelectorAll("[data-view]"),
    pageTitle: document.querySelector("#pageTitle"),
    refreshButton: document.querySelector("#refreshButton"),
    entityForm: document.querySelector("#entityForm"),
    entityId: document.querySelector("#entityId"),
    formFields: document.querySelector("#formFields"),
    formKicker: document.querySelector("#formKicker"),
    formTitle: document.querySelector("#formTitle"),
    submitLabel: document.querySelector("#submitLabel"),
    cancelEditButton: document.querySelector("#cancelEditButton"),
    feedback: document.querySelector("#feedback"),
    searchInput: document.querySelector("#searchInput"),
    resultCount: document.querySelector("#resultCount"),
    tableHead: document.querySelector("#tableHead"),
    tableBody: document.querySelector("#tableBody"),
    statusText: document.querySelector("#statusText"),
    totalGeral: document.querySelector("#totalGeral"),
    metricAreas: document.querySelector("#metricAreas"),
    metricProfessores: document.querySelector("#metricProfessores"),
    metricCursos: document.querySelector("#metricCursos"),
    metricDisciplinas: document.querySelector("#metricDisciplinas")
};

async function requestJson(url, options = {}) {
    const response = await fetch(url, {
        headers: { "Content-Type": "application/json" },
        ...options
    });

    if (!response.ok) {
        const detail = await response.json().catch(() => ({}));
        const message = detail.message || detail.error || Object.values(detail).join(". ");
        throw new Error(message || "Nao foi possivel completar a acao.");
    }

    if (response.status === 204) {
        return null;
    }

    return response.json();
}

async function loadAll() {
    setStatus("Carregando dados...");

    try {
        const [areas, professores, cursos, disciplinas] = await Promise.all([
            requestJson(endpoints.areas),
            requestJson(endpoints.professores),
            requestJson(endpoints.cursos),
            requestJson(endpoints.disciplinas)
        ]);

        state.data.areas = sortByName(areas);
        state.data.professores = sortByName(professores);
        state.data.cursos = sortByName(cursos);
        state.data.disciplinas = sortByName(disciplinas);

        setStatus("Dados atualizados");
        setFeedback("", "");
        render();
    } catch (error) {
        setStatus("Backend indisponivel");
        setFeedback(error.message, "error");
        render();
    }
}

function sortByName(items) {
    return [...items].sort((a, b) => getName(a).localeCompare(getName(b), "pt-BR"));
}

function render() {
    renderShell();
    renderForm();
    renderTable();
    refreshIcons();
}

function renderShell() {
    const active = labels[state.view];
    elements.pageTitle.textContent = active.title;

    elements.navButtons.forEach((button) => {
        button.classList.toggle("is-active", button.dataset.view === state.view);
    });

    elements.metricAreas.textContent = state.data.areas.length;
    elements.metricProfessores.textContent = state.data.professores.length;
    elements.metricCursos.textContent = state.data.cursos.length;
    elements.metricDisciplinas.textContent = state.data.disciplinas.length;
    elements.totalGeral.textContent = Object.values(state.data).reduce((total, list) => total + list.length, 0);
}

function renderForm() {
    const active = labels[state.view];
    elements.formKicker.textContent = state.editingId ? "Editando registro" : "Novo cadastro";
    elements.formTitle.textContent = state.editingId ? active.editTitle : active.formTitle;
    elements.submitLabel.textContent = state.editingId ? "Atualizar cadastro" : "Salvar cadastro";
    elements.cancelEditButton.classList.toggle("is-hidden", !state.editingId);
    elements.formFields.innerHTML = getFormFields(state.view);
}

function getFormFields(view) {
    if (view === "areas") {
        return textField("nome", "Nome da area", "Ex.: Ciencias Exatas");
    }

    if (view === "professores") {
        return [
            textField("nome", "Nome do professor", "Ex.: Ana Martins"),
            textField("email", "Email", "ana@uniguacu.edu.br", "email")
        ].join("");
    }

    if (view === "cursos") {
        return [
            textField("nome", "Nome do curso", "Ex.: Engenharia de Software"),
            selectField("areaConhecimentoId", "Area do conhecimento", state.data.areas),
            selectField("coordenadorId", "Coordenador", state.data.professores)
        ].join("");
    }

    return [
        textField("nome", "Nome da disciplina", "Ex.: Banco de Dados"),
        selectField("cursoId", "Curso", state.data.cursos)
    ].join("");
}

function textField(name, label, placeholder, type = "text") {
    return `
        <div class="field">
            <label for="${name}">${label}</label>
            <input id="${name}" name="${name}" type="${type}" placeholder="${placeholder}" required>
        </div>
    `;
}

function selectField(name, label, options) {
    const optionMarkup = options.map((item) => {
        return `<option value="${item.id}">${escapeHtml(getName(item))}</option>`;
    }).join("");

    return `
        <div class="field">
            <label for="${name}">${label}</label>
            <select id="${name}" name="${name}" required>
                <option value="">Selecione</option>
                ${optionMarkup}
            </select>
        </div>
    `;
}

function renderTable() {
    const records = filteredRecords();
    const columns = getColumns(state.view);

    elements.tableHead.innerHTML = `
        <tr>
            ${columns.map((column) => `<th>${column.label}</th>`).join("")}
            <th>Acoes</th>
        </tr>
    `;

    elements.resultCount.textContent = `${records.length} ${records.length === 1 ? "item" : "itens"}`;

    if (records.length === 0) {
        elements.tableBody.innerHTML = `
            <tr>
                <td class="empty-cell" colspan="${columns.length + 1}">Nenhum registro encontrado</td>
            </tr>
        `;
        return;
    }

    elements.tableBody.innerHTML = records.map((record) => `
        <tr>
            ${columns.map((column) => `<td>${column.render(record)}</td>`).join("")}
            <td>
                <div class="actions">
                    <button class="table-action" type="button" data-action="edit" data-id="${record.id}" title="Editar">
                        <i data-lucide="pencil" aria-hidden="true"></i>
                    </button>
                    <button class="table-action danger" type="button" data-action="delete" data-id="${record.id}" title="Remover">
                        <i data-lucide="trash-2" aria-hidden="true"></i>
                    </button>
                </div>
            </td>
        </tr>
    `).join("");
}

function getColumns(view) {
    const idColumn = {
        label: "Registro",
        render: (item) => `<strong>${escapeHtml(getName(item))}</strong><span>#${item.id}</span>`
    };

    if (view === "professores") {
        return [
            idColumn,
            { label: "Email", render: (item) => escapeHtml(item.email || "-") }
        ];
    }

    if (view === "cursos") {
        return [
            idColumn,
            { label: "Area", render: (item) => escapeHtml(getName(item.areaConhecimento)) },
            { label: "Coordenador", render: (item) => escapeHtml(getName(item.coordenador)) }
        ];
    }

    if (view === "disciplinas") {
        return [
            idColumn,
            { label: "Curso", render: (item) => escapeHtml(getName(item.curso)) }
        ];
    }

    return [idColumn];
}

function filteredRecords() {
    const term = state.search.trim().toLowerCase();
    const records = state.data[state.view];

    if (!term) {
        return records;
    }

    return records.filter((record) => searchText(record).includes(term));
}

function searchText(record) {
    return [
        record.id,
        record.nome,
        record.email,
        getName(record.areaConhecimento),
        getName(record.coordenador),
        getName(record.curso)
    ].filter(Boolean).join(" ").toLowerCase();
}

async function saveRecord(event) {
    event.preventDefault();

    const formData = new FormData(elements.entityForm);
    const payload = buildPayload(state.view, formData);
    const id = state.editingId;
    const url = id ? `${endpoints[state.view]}/${id}` : endpoints[state.view];
    const method = id ? "PUT" : "POST";

    try {
        await requestJson(url, {
            method,
            body: JSON.stringify(payload)
        });

        clearForm();
        await loadAll();
        setFeedback(id ? "Registro atualizado." : "Registro cadastrado.", "success");
    } catch (error) {
        setFeedback(error.message, "error");
    }
}

function buildPayload(view, formData) {
    const nome = formData.get("nome")?.trim();

    if (view === "professores") {
        return {
            nome,
            email: formData.get("email")?.trim()
        };
    }

    if (view === "cursos") {
        return {
            nome,
            areaConhecimentoId: Number(formData.get("areaConhecimentoId")),
            coordenadorId: Number(formData.get("coordenadorId"))
        };
    }

    if (view === "disciplinas") {
        return {
            nome,
            cursoId: Number(formData.get("cursoId"))
        };
    }

    return { nome };
}

function editRecord(id) {
    const record = state.data[state.view].find((item) => item.id === id);

    if (!record) {
        return;
    }

    state.editingId = id;
    renderForm();
    elements.entityId.value = id;
    setFieldValue("nome", record.nome);

    if (state.view === "professores") {
        setFieldValue("email", record.email);
    }

    if (state.view === "cursos") {
        setFieldValue("areaConhecimentoId", record.areaConhecimento?.id);
        setFieldValue("coordenadorId", record.coordenador?.id);
    }

    if (state.view === "disciplinas") {
        setFieldValue("cursoId", record.curso?.id);
    }

    setFeedback("", "");
    document.querySelector("#nome")?.focus();
    refreshIcons();
}

async function deleteRecord(id) {
    const record = state.data[state.view].find((item) => item.id === id);

    if (!record) {
        return;
    }

    if (!window.confirm(`Remover ${getName(record)}?`)) {
        return;
    }

    try {
        await requestJson(`${endpoints[state.view]}/${id}`, { method: "DELETE" });
        clearForm();
        await loadAll();
        setFeedback("Registro removido.", "success");
    } catch (error) {
        setFeedback(error.message, "error");
    }
}

function clearForm() {
    state.editingId = null;
    elements.entityForm.reset();
    elements.entityId.value = "";
    renderForm();
}

function setFieldValue(name, value) {
    const field = elements.entityForm.elements[name];

    if (field) {
        field.value = value ?? "";
    }
}

function setView(view) {
    state.view = view;
    state.search = "";
    elements.searchInput.value = "";
    clearForm();
    render();
}

function setFeedback(message, type) {
    elements.feedback.textContent = message;
    elements.feedback.className = `feedback ${type}`.trim();
}

function setStatus(message) {
    elements.statusText.textContent = message;
}

function getName(item) {
    return item?.nome || "-";
}

function escapeHtml(value) {
    return String(value ?? "")
        .replaceAll("&", "&amp;")
        .replaceAll("<", "&lt;")
        .replaceAll(">", "&gt;")
        .replaceAll('"', "&quot;")
        .replaceAll("'", "&#039;");
}

function refreshIcons() {
    if (window.lucide) {
        window.lucide.createIcons();
    }
}

elements.navButtons.forEach((button) => {
    button.addEventListener("click", () => setView(button.dataset.view));
});

elements.refreshButton.addEventListener("click", loadAll);
elements.entityForm.addEventListener("submit", saveRecord);
elements.cancelEditButton.addEventListener("click", clearForm);

elements.searchInput.addEventListener("input", (event) => {
    state.search = event.target.value;
    renderTable();
    refreshIcons();
});

elements.tableBody.addEventListener("click", (event) => {
    const button = event.target.closest("button[data-action]");

    if (!button) {
        return;
    }

    const id = Number(button.dataset.id);

    if (button.dataset.action === "edit") {
        editRecord(id);
    }

    if (button.dataset.action === "delete") {
        deleteRecord(id);
    }
});

document.addEventListener("DOMContentLoaded", () => {
    render();
    loadAll();
});
